#####################################################################
#        Fonctions necessaires au fonctionnement de l'interface     # 
#####################################################################

from generationCode import UneLEDsurdeux    # Faire briller une LEDs sur deux 
from generationCode import UneLEDsurtrois   # Faire briller une LEDs sur trois
from generationCode import Modechenille     # Faire briller les LEDs en mode Chenille
from generationCode import Modetransition   # Faire briller deuc LEDs a la fois


from generationCode import LEDune
from generationCode import LEDdeux
from generationCode import LEDtrois
from generationCode import LEDquatre
from generationCode import LEDcinq
from generationCode import LEDsix
from generationCode import LEDsept
from generationCode import LEDhuit
from generationCode import LEDneuf
from generationCode import LEDdix
