void setup(){
pinMode(5,OUTPUT);
}
void loop(){
digitalWrite(5,HIGH);
}